Template structure:

index.html
  -> templates/tabs-container.html
     -> templates/tabs-todos.html
     -> templates/tabs-