cd server
./knex.sh migrate:latest
node load_questions.js
