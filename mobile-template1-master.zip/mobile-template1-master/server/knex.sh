../node_modules/knex/lib/bin/cli.js $1 $2 $3 $4 $5
